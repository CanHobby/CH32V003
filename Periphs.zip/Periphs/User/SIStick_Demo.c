/** SIStick_Demo.c
 *  Created on: Jan. 8, 2025
 *      Author: CanHobby.ca
**/

#include "debug.h"
#include "ch32v00x.h"
#include "Periphs.h"

void SisTick_Chg( bool dir ) {

	SysTick->CNT = 0;
//	SysTick->SR &= ~(1 << 0);	// Clear the Compare bit
	if( dir ) { printf("Systick Up");   SysTick->CMP -= 0x00100000; }
	else      { printf("Systick Down"); SysTick->CMP += 0x00100000; }
	if( SysTick->CMP <  0x00100000 ) SysTick->CMP = 0x00400000;
	if( SysTick->CMP >  0x00900000 ) SysTick->CMP = 0x00400000;
	if( SysTick->CMP == 0x00400000 ) printf(" - Reset -- ");
	printf(" = %X\r\n", ((SysTick->CMP) >> 20) );
}

void SisTick_Init() {

	NVIC_EnableIRQ( SysTicK_IRQn ); // Enable SysTicK_IRQ

	SysTick->SR &= ~(1 << 0);	// Clear the Compare bit		   //  enable IRQ
	SysTick->CMP = 0x00400000;    // decrease to run faster
	SysTick->CNT = 0;
	SysTick->CTLR = 0x0B;       // use SysClk / 8 as clock source

#ifdef UART_DEMO
    printf("Systick Init\r\n");
#endif
	}

void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

void SysTick_Handler(void)  //  SisTick Interrupt Handler
{

	GPIO_WriteBit( BlueLED_Port, BlueLED, !GPIO_ReadInputDataBit( BlueLED_Port, BlueLED ) );

    SysTick->SR = 0;  //  clear IRQ
}
