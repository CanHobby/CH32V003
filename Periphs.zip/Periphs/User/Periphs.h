/** Periphs.h
 *  Created on: Jan. 8, 2025
 *      Author: CanHobby.ca
 */

#include <stdint.h>
#include <stdbool.h>
#include "debug.h"

#ifndef USER_PERIPHS_H_
#define USER_PERIPHS_H_

#define Init_Gpios
#define BlueLED_Port GPIOC
#define BlueLED      GPIO_Pin_0

#define YelLED_Port  GPIOD
#define YelLED       GPIO_Pin_0

#define UART_DEMO
#define CHIPID_DEMO
#define SISTICK_DEMO
#define TIMER_DEMO
#define UP true
#define DN false

void Timer_Init( uint16_t arr, uint16_t psc, uint16_t ccp );
void Timer_Chg(  bool     dir );
void GBIO_Blink();
void USART_CFG(void);
void ChipID();
void SisTick_Init();
void SisTick_Chg( bool dir );
void GPIO_Setup();

#endif /* USER_PERIPHS_H_ */
