/** ChipID_Demo.c
 *  Created on: Jan. 8, 2025
 *      Author: CanHoby.ca
 */

#include "Periphs.h"

#include "debug.h"
#define  CHIP_MASK 0xF0500

/**      ChipID List
 *    CH32V003F4P6-0x003005x0
 *    CH32V003F4U6-0x003105x0
 *    CH32V003A4M6-0x003205x0
 *    CH32V003J4M6-0x003305x0
 */

void ChipID() {

	uint32_t chip = DBGMCU_GetCHIPID();
	char     *var;

    printf( "Chip = CH32V%03x ", chip >> 20 );

    if( (chip & CHIP_MASK) == 0x00500 ) var = "F4P6";
    if( (chip & CHIP_MASK) == 0x10500 ) var = "F4U6";
    if( (chip & CHIP_MASK) == 0x20500 ) var = "A4M6";
    if( (chip & CHIP_MASK) == 0x30500 ) var = "J4M6";

    printf( "%s\n", var );

}


